﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Archpack.Training.ArchUnits.Logging.Entities.V1;
using Archpack.Training.ArchUnits.Data.Sql.Pipeline.V1;
using Archpack.Training.ArchUnits.Data.Sql.V1;
using Archpack.Training.ArchUnits.Pipeline.V1;
using Archpack.Training.ArchUnits.Routing.V1;
using Archpack.Training.ArchUnits.Routing.WebApi.V1;
using Archpack.Training.ArchUnits.Validations.V1;
using Archpack.Training.ArchUnits.WebApiExtensions.V1;
using Archpack.Training.ArchUnits.WebApiModels.V1;
using Archpack.Training.ArchUnits.Routing.Pipeline.V1;
using SharedMessage = Archpack.Training.ServiceUnits.Shared.V1.Resources.Messages;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using Archpack.Training.ServiceUnits.Trainings.V1.Resources;
using Archpack.Training.ServiceUnits.Trainings.V1.Data;
//using Archpack.Training.ServiceUnits.Trainings.V1.Lib;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : ApiController
    {
        private ServiceUnitContext serviceUnitContext;
        private DefinitionsEntities context;
        private TraceLogInterceptor traceLogInterceptor;
        
        /// <summary>
        /// 指定された条件でページ一覧ビューを検索した結果を返します 
        /// </summary>
        /// <param name="options"></param>
        /// <returns>ページ一覧ビュー検索結果</returns>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("AwGen.Template", "1.2.0")]
        public $safeitemname$(ServiceUnitContext serviceUnitContext)
        {
            this.serviceUnitContext = serviceUnitContext;
            this.context = DefinitionsEntities.CreateContext();
            this.traceLogInterceptor = context.EnableTraceLog(serviceUnitContext.LogContext);


        }
       
        /// <summary>
        /// DbContext のインスタンスを解放します
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("AwGen.Template", "1.2.0")]
        protected override void Dispose(bool disposing)
        {
        	if (traceLogInterceptor != null)
            {
                traceLogInterceptor.Dispose();
            }

            if (context != null)
            {
                context.Dispose();
            }
        }
    }
}