﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Archpack.Training.ArchUnits.Collections.V1;
using Archpack.Training.ArchUnits.Logging.Entities.V1;
using Archpack.Training.ArchUnits.Data.Sql.Pipeline.V1;
using Archpack.Training.ArchUnits.Data.Sql.V1;
using Archpack.Training.ArchUnits.Pipeline.V1;
using Archpack.Training.ArchUnits.Routing.V1;
using Archpack.Training.ArchUnits.Routing.WebApi.V1;
using Archpack.Training.ArchUnits.Validations.V1;
using Archpack.Training.ArchUnits.WebApiExtensions.V1;
using Archpack.Training.ArchUnits.WebApiModels.V1;
using Archpack.Training.ArchUnits.Routing.Pipeline.V1;
using SharedMessage = Archpack.Training.ServiceUnits.Shared.V1.Resources.Messages;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using Archpack.Training.ServiceUnits.Trainings.V1.Resources;
using Archpack.Training.ServiceUnits.Trainings.V1.Data;
//using Archpack.Training.ServiceUnits.Trainings.V1.Lib;
using Archpack.Training.ArchUnits.Logging.V1;
using Archpack.Training.ArchUnits.Arcs.Logging.V1;
using Archpack.Training.ArchUnits.Arcs.Authentications.V2;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : ApiController
    {
        /// <summary>
        /// 指定された条件でページ一覧ビューを検索した結果を返します 
        /// </summary>
        /// <param name="options"></param>
        /// <returns>ページ一覧ビュー検索結果</returns>
        [HttpGet] // default service is Get. 
        public HttpResponseMessage Search([FromUri]/*TODO: Request parameters*/object request)
        {
            var sqlDefinitionFactory = new FileSqlDefinitionFactory(serviceUnitContext.GetVersionFisicalDirectory());
            var serviceContext = this.Request.GetServiceUnitContext();
            var pipeContext = serviceContext.CreatePipeContext(this.Request);

            /*TODO: use pipe to execute sql, return List<Output parameters>*/
            using (var traceLogger = context.EnableTraceLog(serviceContext.LogContext))
            {
                Pipe pipe = new Pipe(pipeContext)
                    .SetParameters(SetPageSearchParameters)
                    .DataQuery("{sql Search}"); // get name sql page search
                    //.AppendNamedQueryWithCondition(!string.IsNullOrEmpty(/*get attribute*/), "/*TODO: sql page search with condition*/")
                    //.SetParameterWithCondition(!string.IsNullOrEmpty(/*get attribute*/), "{name field}", /*get attribute*/)
                    //.AppendNamedQueryWithCondition(!string.IsNullOrEmpty(/*get attribute*/), "/*TODO: sql page search with condition*/")
                    //.SetParameterWithCondition(!string.IsNullOrEmpty(/*get attribute*/), "{name field}", /*get attribute*/)
                    //.AppendNamedQueryWithCondition((request.Offset.HasValue && request.Next.HasValue), "/*TODO: sql page search with condition*/")
                    //.SetParameterWithCondition((request.Offset.HasValue && request.Next.HasValue), "Offset", ((request.Offset + request.Next) - request.Next + 1))
                    //.SetParameterWithCondition((request.Offset.HasValue && request.Next.HasValue), "Next", request.Offset + request.Next)
                    //.List<{Output parameters}>();
                return pipe.Execute(pipe.CreateRequest(request)).CreateHttpResponse(this.Request, (response, defaultAction) =>
                {
                    // PipeContext からデータを取得し加工する

                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        //var result = response.Data as List<{Output parameters}>;

                        //return this.Request.CreateResponse(HttpStatusCode.OK, result);
                    }
                    return defaultAction();
                });
            }
        }

        /// <summary>
        /// /*TODO: Get data parameter of query*/
        /// </summary>
        /// <param name="pipeContext"></param>
        private void SetPageSearchParameters(PipeContext pipeContext)
        {
            //var parameters = new DataQueryParameters() { DbContext = /*TODO: define entities class name*/.CreateContext() };
            //pipeContext.SetDataQueryParameters("/*TODO: query name of page search*/", parameters);

        }
    }
}